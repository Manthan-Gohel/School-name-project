from django.apps import AppConfig


class PracticeProjectConfig(AppConfig):
    name = 'practice_project'
