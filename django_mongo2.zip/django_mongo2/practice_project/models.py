from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    student_class = models.IntegerField()
    age = models.IntegerField()

    def __str__(self):
        return f"{self.name} - Class {self.student_class}"

