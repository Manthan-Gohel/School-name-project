from django.shortcuts import render, redirect, get_object_or_404
from .models import Student
from .forms import StudentForm
from django.db.models import Q

# CATEGORY PAGE
def categories(request):
    return render(request, "categories.html")

# CLASS STUDENTS VIEW
def class_students(request):
    students = Student.objects.all()
    return render(request, "students.html", {"students": students})
# class students by class_no
def class_students_by_class_no(request, class_no):
    students = Student.objects.filter(student_class=class_no)
    return render(request, "students.html", {"students": students})
# ADD STUDENT
def add_student(request):
    form = StudentForm(request.POST or None)
    if form.is_valid():
        instance = form.save()
        return redirect('class_students')

    return render(request, 'add_student.html', {'form': form})

# UPDATE STUDENT

    
def update_student(request, name): 
    student = get_object_or_404(Student, name=name) 
    if request.method == 'POST':
           student.student_class = request.POST.get("student_class")
           student.age = request.POST.get("age")

           student.objects.filter(name=name).update(student_class=student.student_class,age=student.age)
           return redirect('class_students')
    return render(request, 'update_student.html', {'student': student, 'name': name}) 
    
def delete_student(request, name): 
    Student.objects.filter(name=name).delete() 
    return redirect('class_students')

def search_student(request):
    query = request.GET.get('q')

    if query:
        students = Student.objects.filter(
            name__icontains=query
        )
    else:
        students = Student.objects.none()

    return render(request, "search.html", {
        "students": students,
        "query": query
    })

def search(request):
    query = request.GET.get('q')

    if query:
        students = Student.objects.filter(
            name__icontains=query
        )
    else:
        students = Student.objects.none()

    return render(request, "search.html", {
        "students": students,
        "query": query
    })