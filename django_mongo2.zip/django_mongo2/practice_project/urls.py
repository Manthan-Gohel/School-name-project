from django.urls import path
from . import views

urlpatterns = [
    path('', views.categories, name='categories'),
    path('class_students', views.class_students, name='class_students'),
    path('add-student/', views.add_student, name='add_student'),
    path('update_student/<str:name>/', views.update_student, name='update_student'),
    path('delete-student/<str:name>/', views.delete_student, name='delete_student'),
    path('class_students_by_class_no/<int:class_no>/', views.class_students_by_class_no, name='class_students_by_class_no'),
    path('search-student/<str:name>/', views.search_student, name='search_student'),
    path('search', views.search, name='search'),
]
